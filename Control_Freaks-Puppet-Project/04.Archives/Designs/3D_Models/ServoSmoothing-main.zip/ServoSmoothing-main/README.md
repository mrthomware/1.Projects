# ServoSmoothing

CAD and Code for my simple servo/motion smoothing demo: https://youtu.be/jsXolwJskKM
