---

kanban-plugin: basic

---

## ToDo

- [ ] [[Project Overview Kanban]]
- [ ] [[Timeline Kanban]]
- [ ] [[Tasks Kanban]]
- [ ] [[Progress Updates Kanban]]
- [ ] [[Ideas and Brainstorming Kanban]]
- [ ] [[Team and Roles Kanban]]
- [ ] [[Resources and Documents Kanban]]
- [ ] [[Dependencies and Related Projects Kanban]]
- [ ] [[Notes and Reflections Kanban]]
- [ ] [[References Kanban]]


## Doing

- [ ] Task 3 Build Work Flows (May require New Templates)


## Done

- [x] [[Project - Kanban]]
- [x] [[Making Daily Note Template]]
- [x] [[Making Projects Template]]
- [x] [[Making of Areas - Area of Interest]]
- [x] [[Making Resources Template]]
- [x] [[Making of Archive Document YAML]]


## Archived

- [x] Task 1Make Daily Note Template âœ… 2023-12-16
- [x] Task 2 Start With Daily Note Every Day âœ… 2023-12-16


***

## Archive

- [x] Task 2 Start With Daily Note Every Day âœ… 2023-12-16
- [x] Task 1Make Daily Note Template âœ… 2023-12-16

%% kanban:settings
```
{"kanban-plugin":"basic"}
```
%%