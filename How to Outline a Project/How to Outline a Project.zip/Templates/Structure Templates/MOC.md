{{date:YYYYMMDD}}{{time:HHmm}}
Status: #MOC

Tags: [[Zettelkasten]]

# {{title}}

Map of content for MOC









---
# References
