---
title: "{{date:YYYY-MM-DD}} Daily Note"
date: {{date:YYYY-MM-DD}}
tags: [daily, journal]
created: {{date:YYYY-MM-DDTHH:mm:ss}}
---

### 🗓️ Daily Note: {{date:YYYY-MM-DD}}

#### 📝 Morning Reflection
- Gratitude:
  - [ ] 
- Today's Focus:
  - [ ] 
- Affirmation:
  - [ ] 

#### 📅 Appointments and Meetings
- [ ] Time: Meeting / Event Name
- [ ] Time: Meeting / Event Name

#### 📊 Tasks
- [ ] Task 1
- [ ] Task 2
- [ ] Task 3

#### 📚 Notes and Ideas
- 

#### 🌟 Highlights of the Day
- 

#### 🌙 Evening Reflection
- What went well:
- What could be improved:
- Plans for tomorrow:

#### 🔗 Links and References
- [[Link to another note]]
- External link: [Description](URL)
---

