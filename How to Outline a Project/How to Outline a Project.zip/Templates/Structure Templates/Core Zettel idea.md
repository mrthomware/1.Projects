{{date:YYYYMMDD}}{{time:HHmm}}
Status: #idea

Tags: [[Zettelkasten]]

# {{title}}










---
# References
