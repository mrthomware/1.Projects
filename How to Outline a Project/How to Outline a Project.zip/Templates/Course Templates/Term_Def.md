## Dictionary Definition Template

**Word**: [Word]

**Part of speech**: [Part of speech]

**Pronunciation**: [Pronunciation]

**Meaning**: [Meaning]

**Synonyms**: [Synonyms]

**Antonyms**: [Antonyms]

**Example sentences**:
1. [Example sentence 1]
2. [Example sentence 2]
3. [Example sentence 3]

**Origin**: [Origin]
