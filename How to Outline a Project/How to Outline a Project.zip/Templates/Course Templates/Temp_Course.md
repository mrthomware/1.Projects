::: {#626353b5-7170-4a5c-92c9-f32c754193f6 .cell .code}
``` python
TEMP_cOURSE
```
:::
